// ==UserScript==
// @name         swagger_code_generator
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  generate code from swagger.
// @author       You
// @match        https://qa.sms.91dev.tw/swagger/*
// @grant        none
// @require      https://s3-us-west-2.amazonaws.com/s.cdpn.io/14082/FileSaver.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/jszip/2.6.0/jszip.js
// @run-at       document-idle
// ==/UserScript==
/* jshint -W097 */
'use strict';

$(function(){
    //自定義handlebar helper
    Handlebars.registerHelper('list', function(items, tail, options) {
        if(items.length === 0){
            return;
        }
        var s = '';
        for(var i = 0, l = items.length-1 ; i < l ; i++){
            s += options.fn(items[i])+tail+' ';
        }
        return s+options.fn(items[items.length-1]);
    });

    Handlebars.registerHelper('toLowerCase', function(value) {
        if(value) {
            return new Handlebars.SafeString(value[0].toLowerCase()+value.slice(1));
        } else {
            return '';
        }
    });


    // 如果要加 put和delete這邊要加
    var requestType = ['get', 'post', 'put'];

    // template套資料
    var parse = function(){
        $('body').append('<div class="block-ui" style="position: fixed; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index:9999; top: 0; left: 0"></div>');

        $.ajax({
            url: "/swagger/docs/v1",
            type: "GET",
            dataType: "json",
            success: function(json) {
                console.log(json);
                var paths = json.paths;
                for(var key in json.paths){
                    var path = paths[key];
                    for(var requestWay in path){
                        var contentElm = $('a:contains('+ key +')').parent().parent().find('a:contains('+ requestWay +')').parent().parent().parent().parent().find('.content')

                        if(contentElm){
                            var tempKey = key.split('/');
                            var context = {
                                "tag": path[requestWay].tags[0],
                                "apiUrl": key,
                                "api名稱": path[requestWay].operationId.split('_')[1],
                                "參數":[],
                                "request方法": requestWay,
                                "api說明": path[requestWay].parameters && path[requestWay].parameters[0].description || path[requestWay].summary 
                            };

                            if(path[requestWay].parameters){
                                try{
                                    switch(requestWay.toLowerCase()){
                                        case 'post':
                                            var schema = path[requestWay].parameters[0].schema;
                                            if(schema){
                                                var ref = schema.$ref;
                                                if(ref){
                                                    var definitionName = ref.split('/')[2];             
                                                    var properties =json.definitions[definitionName].properties;
                                                    for(var key in properties){
                                                        context['參數'].push({
                                                            "名稱": key,
                                                            "型別": properties[key].type
                                                        });
                                                    }
                                                }else{
                                                    context['參數'].push({
                                                        "名稱": 'list',
                                                        "型別": 'any'
                                                    });
                                                }
                                            }
                                            break;
                                        case 'get':                           
                                            var properties =path[requestWay].parameters;
                                            properties.forEach(function(properity, index){
                                                context['參數'].push({
                                                    "名稱": properity.name,
                                                    "型別": properity.type,
                                                    "required": properity.required
                                                });
                                            })
                                            context["apiUrl"] = context["apiUrl"].replace(/\/\{[a-z]+\}/gi,'');
                                            context["api說明"] = path[requestWay].summary; 
                                            break;
                                        default:
                                            break;
                                    }                                                                     
                                }catch(err){
                                    console.log('--'+requestWay+'--');
                                    console.log(tempKey);
                                    console.log(err);
                                    debugger;

                                }
                            }


                            var serviceContainerElm = contentElm.find('.service-container');

                            if(serviceContainerElm.length === 0){
                                contentElm.append('<div class="service-container"></div>');
                                serviceContainerElm = contentElm.find('.service-container');
                            }


                            var serviceSource = $('.'+requestWay+'-template').val();

                            if(serviceSource){
                                var serviceTemplate = Handlebars.compile(serviceSource);
                                serviceContainerElm.html('<h4>service: '+ context.apiUrl +'</h4>' + serviceTemplate(context));
                            }

                        }
                    }
                }

                $('.block-ui').remove();
            },
            error: function(err) {
                console.log('getTemplates err!');
                alert('failed to generate code');
                $('.block-ui').remove();
            }
        }) 
    };

    parse();

    // UI操作
    var settingTemplate = function(way){
        $('.setting-container').append('<p>'+ way +' template</p><textarea class="'+ way +'-template" style="width:100%"></textarea>')
    };

    $('body').append('<div id="code-gen-container" style="position:fixed; left:0; top: 80px; width: 100px; padding: 0 3px; background-color: #fff">' +
                     '<div class="template-container"></div>'+
                     '<button class="generate-btn" style="width: 100%; height: 30px; border-radius:0; background-color: #89bf04; border: none; color: #fff; outline: none; cursor: pointer; margin-top: 5px">Generate</button>'+
                     '<button class="download-btn" style="width: 100%; height: 30px; border-radius:0; background-color: #89af04; border: none; color: #fff; outline: none; cursor: pointer; margin-top: 5px">download</button>'+
                     '</div>'
                    ); 

    $('.create-new-setting-btn').on('click', function(e){
        var way = $('.new-setting-way').val();
        settingTemplate(way);
    })

    $('.generate-btn').on('click', function(e){
        parse();
    })

    $('.post-template').on('input', function(e){
        localStorage.setItem('post-template', $('.post-template').val());  
    })

    $('.download-btn').on('click', function(e){
        //if (window.saveAs) {
            var zip = new JSZip();
            var resourceList = $('#resources_container .resource');

            resourceList.each(function(index, resource){
                var resourceName = $(resource).find('h2 a').text();
                var fineName = resourceName[0].toLowerCase() + resourceName.slice(1);
                var content = '';
                $(resource).find('.language-typescript').each(function(index, code){
                    content += $(code).text();
                }) 
                console.log(content);
                zip.file(fineName+'.ts', content);
            })
            
            saveAs(zip.generate({type:"blob"}), "service.zip");
        //}else{
         //   console.log("saveAs not supported")
        //}
    })


    requestType.forEach(function(type, index){

        var template = localStorage.getItem(type+'-template');

        $('.template-container').append(
            '<p style="margin:15px 0 2px; font-size: 13px;">'+ type +'</p>'+
            '<textarea class="'+ type +'-template" style="width:100%; box-sizing: border-box"></textarea>'
        );

        if(template){
            $('.'+type+'-template').val(template);
        }

        $('.'+type+'-template').on('input change', function(e){
            localStorage.setItem(type+'-template', $('.'+type+'-template').val());  
        })

        /*
        $('.'+type+'-template').on('mouseenter', function(e){
            $(this).css({
                width: '500px',
                height: '400px'
            });
        })

        $('.'+type+'-template').on('mouseleave', function(e){
            $(this).css({
                width: '100%',
                height: '36px'
            });
        })*/
    })



});

